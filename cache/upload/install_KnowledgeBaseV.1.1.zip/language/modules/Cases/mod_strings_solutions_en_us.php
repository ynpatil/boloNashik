<?php
/*******************************************************************************
 * Cases module needs to now the new subpanel title
 ******************************************************************************/
$mod_strings['LBL_SOLUTIONS_SUBPANEL_TITLE'] = 'Solutions';
?>
