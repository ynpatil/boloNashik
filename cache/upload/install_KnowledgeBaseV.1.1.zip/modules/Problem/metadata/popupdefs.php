<?php
if(empty($GLOBALS['sugarEntry'])) die('Not A Valid Entry Point');
/*********************************************************************************
 * 
 ********************************************************************************/

$popupMeta = array('moduleMain' => 'Problem',
						'varName' => 'PROBLEM',
						'orderBy' => 'name',
						'whereClauses' => 
							array('name' => 'problem.name'),
						'searchInputs' =>
							array('name')
						);


?>
 
 
