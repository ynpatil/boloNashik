<?php
if(empty($GLOBALS['sugarEntry'])) die('Not A Valid Entry Point');
/**
 * Popup
 */

require_once('include/Popups/Popup_picker.php');

			
$popup = new Popup_Picker();

echo $popup->process_page();

?>
