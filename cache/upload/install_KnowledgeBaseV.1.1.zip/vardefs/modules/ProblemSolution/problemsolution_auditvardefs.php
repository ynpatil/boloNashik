<?PHP
$dictionary['problem_solution']['fields']['audit'] = array (
  		'name' => 'audit',
    		'type'  => 'link',
    		'source'=> 'non-db',
  		);

?>