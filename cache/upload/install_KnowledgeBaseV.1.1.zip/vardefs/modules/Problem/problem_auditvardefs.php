<?PHP
$dictionary['problem']['fields']['audit'] = array (
  		'name' => 'audit',
    		'type'  => 'link',
    		'source'=> 'non-db',
  		);

?>