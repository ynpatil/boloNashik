<?php

//rebuild dashlets
require_once('modules/Administration/RebuildDashlets.php');

?>