<?php
$dictionary['forums']['fields']['threads'] =
        array (
  		    'name' => 'threads',
    		'type' => 'link',
    		'relationship' => 'forums_threads',
    		'source'=>'non-db',
  		);

?>
