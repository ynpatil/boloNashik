<?php
$dictionary['threads']['fields']['posts'] =
        array (
  		    'name' => 'posts',
    		'type' => 'link',
    		'relationship' => 'threads_posts',
    		'source'=>'non-db',
  		);

?>
