<?php

$mod_strings['LBL_THREADS_SUBPANEL_TITLE'] = 'Threads';

?>
