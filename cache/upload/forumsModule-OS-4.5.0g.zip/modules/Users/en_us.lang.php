<?

    $mod_strings['LBL_THREAD_DISPLAY'] = 'Thread Display Style:';
    $mod_strings['LBL HREAD_DISPLAY_TEXT'] = 'Select how the structure of a Forums thread should be displayed';

?>