<?php

require_once('include/Popups/Popup_picker.php');

$popup = new Popup_Picker();

echo $popup->process_page();

?>