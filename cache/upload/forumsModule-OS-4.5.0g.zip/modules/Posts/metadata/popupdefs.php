<?php

$popupMeta = array('moduleMain' => 'Post',
						'varName' => 'POST',
						'className' => 'Post',
						'orderBy' => 'title',
						'whereClauses' => 
							array('name' => 'post.title', 
							),
						'searchInputs' =>
							array('title')
						);

?>
