<?php
/*
$mod_strings['LBL_FORUM_CONFIG_TITLE'] = 'Configure Forums';
$mod_strings['LBL_FORUM_CONFIG_DESC']  = 'Set up various default settings for forums.';
$mod_strings['LBL_FORUM_CONFIG_HEADER']='Forums';
*/
$mod_strings['LBL_FORUM_TOPICS_TITLE'] = 'Forum Topics';
$mod_strings['LBL_FORUM_TOPICS_DESC'] = 'Create and Edit Forum Topics and the order they appear in.';

?>
