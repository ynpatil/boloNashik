<?php 
/*
***** SugarTime *****
Developed by Paul K. Lynch, Everyday Interactive Networks (ein.com.au)
Mozilla Public License v1.1
*/

global $mod_strings, $app_strings;
$module_menu = Array(

	// Nothing Yet

	);

?>