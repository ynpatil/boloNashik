<?php
/*
***** SugarTime *****
Developed by Paul K. Lynch, Everyday Interactive Networks (ein.com.au)
Mozilla Public License v1.1
*/

// Not in use yet
$mod_strings['LBL_1']='Thing One';
$mod_strings['LBL_2']='Thing Two';
$mod_strings['LBL_TIME_CONFIG_TITLE']='SugarTime';
?>
