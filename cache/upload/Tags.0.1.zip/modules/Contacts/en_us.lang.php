<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

$mod_strings['LBL_TAGS_SUBPANEL_TITLE'] = 'Tags';
?>
