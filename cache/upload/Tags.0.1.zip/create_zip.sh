#!/bin/sh 

VERSION="0.1"

zip -r ../Tags.${VERSION}.zip . -x \*CVS\*
