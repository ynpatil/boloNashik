<?PHP
//*********************************************************************************
// * Module: Template - By Olavo Farias
// * File:   mod_app_strings.php
// * Descr:  Template module Tab name and enumerated definitions
// ********************************************************************************/
$app_list_strings['moduleList']['SugarChat']='SugarChat';
?> // End of _dom files