<?PHP
$app_list_strings['moduleList']['ZuckerDocs']='ZuckerDocs';

if (!array_key_exists('doc_category', $app_list_strings)) {
	$app_list_strings['doc_category']= array (
			'Generic' => 'Allgemein',
			'Business Reports' => 'Gesch&auml;ftsberichte',
			'Bug Description' => 'Fehlerbeschreibungen',
			'Document Template' => 'Dokumentenvorlagen'
		);
}
?>