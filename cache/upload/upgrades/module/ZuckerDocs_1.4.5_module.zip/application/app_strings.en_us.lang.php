<?PHP
$app_list_strings['moduleList']['ZuckerDocs']='ZuckerDocs';

if (!array_key_exists('doc_category', $app_list_strings)) {
	$app_list_strings['doc_category']= array (
			'Generic' => 'Generic',
			'Business Reports' => 'Business Reports',
			'Bug Description' => 'Bug Descriptions',
			'Document Template' => 'Document Templates'
		);
}
?>