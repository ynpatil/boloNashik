<?php
// Creation date: 2006-05-05 22:35:09
// Module: Accounts
// Language: en_us

$mod_strings['LBL_MAP'] = 'Get Map';
$mod_strings['LBL_DIRECTIONS'] = 'Get Directions';
?>