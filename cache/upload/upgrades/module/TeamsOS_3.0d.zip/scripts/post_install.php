<?php
require_once('include/database/PearDatabase.php');
function post_install() {

}
?>