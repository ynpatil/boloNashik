<?php

$mod_strings['LBL_MANAGE_TEAMS_TITLE'] = 'Team Management';
$mod_strings['LBL_MANAGE_TEAMS'] = 'Team Management Editor';

?>
