<?php

$mod_strings['LBL_MANAGE_TEAMS_TITLE'] = 'Группы';
$mod_strings['LBL_MANAGE_TEAMS'] = 'Управление группами';

?>
                                