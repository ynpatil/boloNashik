<?php

$mod_strings['LBL_MANAGE_TEAMS_TITLE'] = 'Administraci�n de Equipos';
$mod_strings['LBL_MANAGE_TEAMS'] = 'Administra la pertenencia a equipos y sus propiedades';

?>
