<?php

$mod_strings['LBL_MANAGE_TEAMS_TITLE'] = "Gestion des &eacute;quipes";
$mod_strings['LBL_MANAGE_TEAMS'] = "Editeur de gestion des &eacute;quipes";

?>
