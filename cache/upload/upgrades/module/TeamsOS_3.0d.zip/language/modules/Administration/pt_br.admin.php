<?php

$mod_strings['LBL_MANAGE_TEAMS_TITLE'] = 'Ger�ncia da equipe';
$mod_strings['LBL_MANAGE_TEAMS'] = 'Editor da ger�ncia da equipe';

?>
