<?php
	$mod_strings['LBL_CREATE_TEAMS'] = 'Cr&eacute;er une nouvelle &eacute;quipe pour cet utilisateur';
	$mod_strings['LBL_DEFAULT_TEAM'] = '&Eacute;quipe par d&eacute;faut:';
	$mod_strings['LBL_DEFAULT_TEAM_DESC'] = "Transf&eacute;rer l'&eacute;quipe sur des objets cr&eacute;&eacute;s par cet utilisateur.<br>Liste des &eacute;quipes en cours: ";
	$mod_strings['LBL_SHOW_ALL_TEAMS'] = 'Montrer toutes les &eacute;quipes:';
	$mod_strings['LBL_SHOW_ALL_TEAMS_DESC'] = "Permettre &agrave; cet utilisateur d'assigner des objets &agrave; n'importe quelle &eacute;quipe ind&eacute;pendamment de son appartenance &agrave; une &eacute;quipe.";
	$mod_strings['LBL_SELECT_TEAM'] = 'Choisir une &eacute;quipe';
	$mod_strings['LBL_NO_TEAMS'] = "Membre d'aucune &eacute;quipe";
	$mod_strings['LBL_NO_TEAM'] = 'Aucune &eacute;quipe';
	$mod_strings['LBL_PRIVATE_TEAM'] = "Rendre l'&eacute;quipe priv&eacute;e";

	//orgchart addon
	$mod_strings['LBL_ORGCHART_COMPANY'] = "Organigramme";
	$mod_strings['LBL_ORGCHART_TITLE'] = "Organigramme - utilisateurs";
	$mod_strings['LBL_ORGCHART_1ST_ENTITY'] = "Utilisateur inactif";
	$mod_strings['LBL_ORGCHART_2ND_ENTITY'] = "Utilisateur actif";
	$mod_strings['LBL_ORGCHART_3RD_ENTITY'] = "Employ&eacute; seulement";
	$mod_strings['LBL_ORGCHART_CURR_RECORD'] = "Enregistrement en cours";
	$mod_strings['LBL_ORGCHART_NOT_AUTHORIZED'] = "Non autoris&eacute;";
	$mod_strings['LBL_ORGCHART_NOT_AUTORIZED_MSG'] = "Vous n'&ecirc;tes pas autoris&eacute; &agrave; voir cet utilisateur!";
	$mod_strings['LBL_ORGCHART_CIRCULAR_REFERENCE'] = "R&eacute;f&eacute;rence p&eacute;riph&eacute;rique";
	$mod_strings['LBL_ORGCHART_DESCRIPTION'] = "L&eacute;gende";
?>
