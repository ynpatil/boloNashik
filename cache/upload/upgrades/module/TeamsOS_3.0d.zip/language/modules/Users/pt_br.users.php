<?php
	$mod_strings['LBL_CREATE_TEAMS'] = 'Criar uma equipe nova para este usu�rio';
	$mod_strings['LBL_DEFAULT_TEAM'] = 'Equipe do defeito:';
	$mod_strings['LBL_DEFAULT_TEAM_DESC'] = 'Optar pela equipe nos objetos criados por este usu�rio.<br>Lista atual da equipe: ';
	$mod_strings['LBL_SHOW_ALL_TEAMS'] = 'Mostrar todas as equipes:';
	$mod_strings['LBL_SHOW_ALL_TEAMS_DESC'] = 'Permitir que este usu�rio atribua objetos a toda a equipe n�o obstante a sociedade da equipe.';
	$mod_strings['LBL_SELECT_TEAM'] = 'Selecionar uma equipe';
	$mod_strings['LBL_NO_TEAMS'] = 'N�o um membro de algumas equipes';
	$mod_strings['LBL_NO_TEAM'] = 'Nenhuma equipe';
	$mod_strings['LBL_PRIVATE_TEAM'] = "Fazer a equipe confidencial";

	//orgchart addon
	$mod_strings['LBL_ORGCHART_COMPANY'] = "Organograma";
	$mod_strings['LBL_ORGCHART_TITLE'] = "Organograma dos Usu�rios";
	$mod_strings['LBL_ORGCHART_1ST_ENTITY'] = "Usu�rio Inativo";
	$mod_strings['LBL_ORGCHART_2ND_ENTITY'] = "Usu�rio Ativo";
	$mod_strings['LBL_ORGCHART_3RD_ENTITY'] = "Funcion�rio";
	$mod_strings['LBL_ORGCHART_CURR_RECORD'] = "Registro Atual";
	$mod_strings['LBL_ORGCHART_NOT_AUTHORIZED'] = "N�o Autorizado";
	$mod_strings['LBL_ORGCHART_NOT_AUTORIZED_MSG'] = 'Voc� n�o est� autorizado a acessar este usu�rio!';
	$mod_strings['LBL_ORGCHART_CIRCULAR_REFERENCE'] = 'Refer�ncia Circular';
	$mod_strings['LBL_ORGCHART_DESCRIPTION'] = 'Legenda';
?>
