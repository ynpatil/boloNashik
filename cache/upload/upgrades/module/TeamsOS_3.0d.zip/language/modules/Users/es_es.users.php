<?php
	$mod_strings['LBL_CREATE_TEAMS'] = 'Crear a nuevo equipo para este usuario';
	$mod_strings['LBL_DEFAULT_TEAM'] = 'Equipo predeterminado:';
	$mod_strings['LBL_DEFAULT_TEAM_DESC'] = 'Equipo prederminado en la creaci�n de objetos por este usuario.<br>Lista actual de equipos: ';
	$mod_strings['LBL_SHOW_ALL_TEAMS'] = 'Mostrar todos los equipos:';
	$mod_strings['LBL_SHOW_ALL_TEAMS_DESC'] = 'Permitir que este usuario asigne objetos a cualquier equipo sin importar si es miembro del equipo.';
	$mod_strings['LBL_SELECT_TEAM'] = 'Seleccione equipo';
	$mod_strings['LBL_NO_TEAMS'] = 'No un miembro de ning�n equipo';
	$mod_strings['LBL_NO_TEAM'] = 'Ning�n equipo';
	$mod_strings['LBL_PRIVATE_TEAM'] = "Hacerlo un equipo privado";

	//orgchart addon
	$mod_strings['LBL_ORGCHART_COMPANY'] = "Organigrama";
	$mod_strings['LBL_ORGCHART_TITLE'] = "Organigrama - Ssuarios";
	$mod_strings['LBL_ORGCHART_1ST_ENTITY'] = "Usuario inactivo";
	$mod_strings['LBL_ORGCHART_2ND_ENTITY'] = "Usuario activo";
	$mod_strings['LBL_ORGCHART_3RD_ENTITY'] = "Empleado solamente";
	$mod_strings['LBL_ORGCHART_CURR_RECORD'] = "Registro actual";
	$mod_strings['LBL_ORGCHART_NOT_AUTHORIZED'] = "No autorizado";
	$mod_strings['LBL_ORGCHART_NOT_AUTORIZED_MSG'] = 'No esta autorizado para ver a este usuario!';
	$mod_strings['LBL_ORGCHART_CIRCULAR_REFERENCE'] = 'Referencia circular';
	$mod_strings['LBL_ORGCHART_DESCRIPTION'] = 'Leyenda';
?>
