<?php
	$mod_strings['LBL_CREATE_TEAMS'] = 'Создать новую группу для этого пользователя';
	$mod_strings['LBL_DEFAULT_TEAM'] = 'Группа по умолчанию:';
	$mod_strings['LBL_DEFAULT_TEAM_DESC'] = 'Вcе объекты по умолчанию будут принадлежать данной группе.<br>Доступные группы: ';
	$mod_strings['LBL_SHOW_ALL_TEAMS'] = 'Show All Teams:';
	$mod_strings['LBL_SHOW_ALL_TEAMS_DESC'] = 'Разрешить этому пользователю создавать объекты в любой группе';
	$mod_strings['LBL_SELECT_TEAM'] = 'Выбрать группу';
	$mod_strings['LBL_NO_TEAMS'] = 'Не принадлежит не одной группе';
	$mod_strings['LBL_NO_TEAM'] = 'Без группы';

	//orgchart addon
	$mod_strings['LBL_ORGCHART_COMPANY'] = "Структура организации";
	$mod_strings['LBL_ORGCHART_TITLE'] = "Структура организации - пользователи";
	$mod_strings['LBL_ORGCHART_1ST_ENTITY'] = "Уволенный пользователь";
	$mod_strings['LBL_ORGCHART_2ND_ENTITY'] = "Активный пользователь";
	$mod_strings['LBL_ORGCHART_3RD_ENTITY'] = "Только сотрудники";
	$mod_strings['LBL_ORGCHART_CURR_RECORD'] = "Текущая запись";
	$mod_strings['LBL_ORGCHART_NOT_AUTHORIZED'] = "Нет доступа";
	$mod_strings['LBL_ORGCHART_NOT_AUTORIZED_MSG'] = 'You are not authorized to view this user!';
	$mod_strings['LBL_ORGCHART_CIRCULAR_REFERENCE'] = 'Circular Reference';
	$mod_strings['LBL_ORGCHART_DESCRIPTION'] = 'Легенда';

?>
