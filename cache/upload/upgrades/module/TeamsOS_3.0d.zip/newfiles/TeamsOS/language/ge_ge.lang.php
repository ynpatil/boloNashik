<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

$mod_strings = array (
	'LBL_NEW_FORM_TITLE' => 'Neues Team',
	'LBL_MODULE_NAME' => 'Lampada Teams Open Source',
	'LBL_MODULE_TITLE' => 'Team: Home',
	'LBL_LIST_FORM_TITLE' => 'Team Liste',
	'LBL_ADD_TEAM' => 'Neues Team',
	'LBL_LIST_TEAMS' => 'Teams',
	'LBL_ID' => 'Id',
	'LBL_PRIVATE' => 'Privates Team',
	'LBL_NAME' => 'Name',
	'LBL_TEAMURL' => 'Teamurl',
	'LBL_STATUS' => 'Status',
	'LBL_DELETED' => 'gel�scht',
	'LBL_DATE_ENTERED' => 'Date_entered',
	'LBL_DATE_MODIFIED' => 'Date_modified',
	'LBL_CREATED_BY' => 'Created_by',
	'LBL_SEARCH_FORM_TITLE' => 'Suche',
	'LBL_ASSIGNED_TO_NAME' => 'Assigned User Name:',
	'LBL_USERS_SUBPANEL_TITLE' => 'Benutzer',
	'LBL_USERS' => 'Benutzer',
	'LBL_MODULE_NAME' => 'Team',
	'LBL_MODULE_TITLE' => 'Team: Home',
	'LBL_SEARCH_FORM_TITLE' => 'Team Suche',
	'LBL_TEAM_MEMBERS' => 'Others in this team by virtue of the \'reports to\' field:<br>',
	'LBL_LIST_FORM_TITLE'=> 'Team Liste',
	'LBL_NO_TEAM'=>'--keins--'
);
?>
