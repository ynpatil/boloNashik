
<?php
require_once('modules/TeamsOS/TeamFormBase.php');
$TeamForm = new TeamFormBase();
$TeamForm->handleSave('', true, false);
?>
