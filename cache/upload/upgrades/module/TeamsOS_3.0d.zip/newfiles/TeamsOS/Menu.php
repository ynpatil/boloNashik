
<?php 
global $mod_strings;
$module_menu = array();
$module_menu[] = array('index.php?module=TeamsOS&action=EditView&return_module=TeamsOS&return_action=DetailView', $mod_strings['LBL_ADD_TEAM'], 'TeamsOS');
$module_menu[] = array('index.php?module=TeamsOS&action=index&return_module=TeamsOS&return_action=DetailView', $mod_strings['LBL_LIST_TEAMS'],  'TeamsOS');

?>
