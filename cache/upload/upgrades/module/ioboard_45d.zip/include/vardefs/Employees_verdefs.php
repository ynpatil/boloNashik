<?php
$dictionary['User']['fields']['iostatus_options'] = array (
		'name'         => 'iostatus_options',
		'type'         => 'vardef',
  		'ignore_role'  =>  true,
		'source'       => 'non-db',
);
$dictionary['User']['fields']['iomsg_text'] = array (
		'name'         => 'iomsg_text',
		'type'         => 'vardef',
  		'ignore_role'  =>  true,
		'source'       => 'non-db',
);
?>