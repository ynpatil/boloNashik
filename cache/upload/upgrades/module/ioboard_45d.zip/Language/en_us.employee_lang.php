<?php
$mod_strings['LBL_LIST_IOSTATUS'] = 'In/Out Status';
$mod_strings['LBL_MESSAGE'] = 'Message Text';
$mod_strings['LBL_TEAMS'] = 'Teams:';
?>