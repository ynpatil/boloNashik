<?php
$app_strings['io_board_dom']['In'] = 'In';
$app_strings['io_board_dom']['Out'] = 'Out';
$app_strings['io_board_dom']['Lunch'] = 'Lunch';
$app_strings['io_board_dom']['Dinner'] = 'Dinner';
$app_strings['io_board_dom']['Meeting'] = 'Meeting';
$app_strings['io_board_dom']['Vacation'] = 'Vacation';
$app_strings['io_board_dom']['Out Of Town'] = 'Out Of Town';
$app_strings['io_board_dom']['Unavailable'] = 'Unavailable';

//Do not translate colors below!
$app_strings['io_board_color_dom']['In'] = 'green';
$app_strings['io_board_color_dom']['Out'] = 'red';
$app_strings['io_board_color_dom']['Lunch'] = 'yellow';
$app_strings['io_board_color_dom']['Dinner'] = 'yellow';
$app_strings['io_board_color_dom']['Meeting'] = 'yellow';
$app_strings['io_board_color_dom']['Vacation'] = 'red';
$app_strings['io_board_color_dom']['Out Of Town'] = 'red';
$app_strings['io_board_color_dom']['Unavailable'] = 'red';
?>